﻿using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;

namespace CW2
{
    class Program
    {
        static void Main(string[] args)
        {


            Ticket TestTicket = new Ticket("1", "Eli", "Vance", 43245431, "evance@mail.com", "needs fitting bulb and teleport machine", "Residential", "Closed");
            Ticket TestTicket2 = new Ticket("2", "Isaac", "Kleiner", 01238543, "ikleiner@mail.com", "pest infection", "Comercial", "Opened");

            // Adding tickets ------------------------------------
            TicketManager.AddTicket(TestTicket);
            TicketManager.AddTicket(TestTicket2);
            // ----------------------------------------------------



            // Ticket search by tenant's name ---------------------------------
            Console.WriteLine("Input search tenant's surname ");
            string search = Console.ReadLine();
            var results = TicketManager.SearchTickets(search);

          
            if (results.Count != 0)
            {
                foreach (Ticket item in results)
                {
                    Console.WriteLine("\n********************************\n");
                    Console.WriteLine($"1. Ticket ID: {item.ticketid}");
                    Console.WriteLine($"2. Tenant's First Name: {item.tenantname}");
                    Console.WriteLine($"3. Tenant's Second Name: {item.tenantsname}");
                    Console.WriteLine($"4. Tenant's E-mail address: {item.tenantemail}");
                    Console.WriteLine($"5. Tenant's phone nubmer: {item.tenantnumber}");
                    Console.WriteLine($"6. Issues: {item.issues}");
                    Console.WriteLine($"7. Issue type: {item.propertytype}");
                    Console.WriteLine($"8. Exit");
                    Console.WriteLine("\n********************************\n");

                }
            }
            else
            {
                Console.WriteLine("Sorry, no tenants wtih this surname are registered");
            }
            CreateTicket();
        }
        // ---------------------------------------------------------------
        
            


     

       
        // ------------------------------------------------------------------



        // Add new ticket --------------------------------------------------

        public static Ticket CreateTicket()
            {
                // Create object from user input
                Console.WriteLine("*************\nCreate Customer\n**************");
                Console.WriteLine("Enter Customer First Name");
                string tenantname = Console.ReadLine();

                Console.WriteLine("Enter Customer Second Name");
                string tenantsname = Console.ReadLine();

                Console.WriteLine("Enter Customer Address");
                string tenantemail = Console.ReadLine();

                Console.WriteLine("Enter Customer Phone number");
                int tenantnumber  = Convert.ToInt32(Console.ReadLine());

                Console.WriteLine("Enter issues");
                string issues = Console.ReadLine();

                Console.WriteLine("Enter issue type (1 - Resindetial, 2 - Commercieal)");
                string propertytype = Console.ReadLine();
                if (propertytype == "1")
                   {
                    propertytype = "Residential";
                   }
                if (propertytype == "2")
                {
                    propertytype = "Comercial";
                }
                else
                {
                    Console.WriteLine("Should be a number");
                }
                 Console.WriteLine("Enter status type (1 - Opened , 2 - Closed)");
                 string status = Console.ReadLine();
                if (status == "1")
                {
                    status = "Opened";
                }
                if (status == "2")
                {
                    status = "Closed";
                }
                else
                {
                    Console.WriteLine("Should be a number");
                }

                  Ticket TestTicket3 = new Ticket(tenantname, tenantsname, tenantemail, tenantnumber, tenantemail, issues, propertytype, status);
                  Console.WriteLine(TestTicket3);
                  return TestTicket3;

            }



            /*
            Console.WriteLine("Create a new ticket");
            Console.WriteLine("Type tenants' first name: ");
            string tenantname = Console.ReadLine();
           
            Console.WriteLine("Type tenants' first name: ");
            string tenantsname = Console.ReadLine();
            Console.WriteLine("Type tenants' surname name: ");

            Console.WriteLine();

            // ------------------------------------------------------------------

            /*
            Initialise.Init();

            while (true)
            {
                CLI.Login();
            }
            


            // JSON example
            
         
            List<Ticket> tickets = new List<Ticket>();
            tickets.Add(TestTicket);

            var json = JsonConvert.SerializeObject(tickets);


            using (StreamWriter file = File.CreateText(@"C:\Users\Michael\Desktop\Uni\SCDT41 Programming and Software Fundamentals (James Shaun)\Assignment 2\CW2\test.json"))
            {
                JsonSerializer serializer = new JsonSerializer();
                serializer.Serialize(file, TestTicket);

            }
            //Console.WriteLine(json);
           
            */


        }
    }

