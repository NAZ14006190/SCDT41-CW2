﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CW2
{
    public class Labourer : User
    {

        public int labourerID;
        public string fname;
        public string sname;
        public int phone_num;
        public string email;

        public Labourer(int ClerkID, string Fname, string Sname, int Phone_num, string Email) : base(Fname, Sname, Phone_num, Email)
        {
            this.labourerID = ClerkID;
            this.fname = Fname;
            this.sname = Sname;
            this.phone_num = Phone_num;
            this.email = Email;
        }

    }
}
