﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CW2
{
    public class CLI
    {

        public static void Login()
        {
            Console.WriteLine("Enter your ID:");
            int id = Convert.ToInt32(Console.ReadLine());
;
        

            if (id == 1)
            {
                Console.WriteLine("Access type: Clerk");
              
            }
            if (id == 2)
            {
                Console.WriteLine("Access type: Labourer");
            }
            else
            {
                Console.WriteLine("Wrong ID");
            }
        
          
        }

        public static void NewTicket(Clerk clerk)
        {
            bool menu = true;
            while (menu)
            {
                Console.WriteLine("\n#######################################################\n");
                Console.WriteLine("Please select from the following options:");
                Console.WriteLine("\n1: Withdraw\n2: Deposit\n3: Change PIN\n4: View Transactions\n5: Exit\n");

                string choice = Console.ReadLine();

                switch (choice)
                {
                    case "1":
                        break;
                    case "2":
                        break;
                    case "3":
                        break;
                    case "4":
                        break;
                    case "5":
                        menu = false;
                        break;
                    default:
                        Console.WriteLine("Input not recognise - please try again");
                        break;
                }
            }

            
        }
        public static void ChangeParameters(Ticket ticket)
        {
            Console.WriteLine("Would like to make any changes?");
            string choice1 = Console.ReadLine();

            switch (choice1)
            {
                case "1":
                    Console.WriteLine("Type new Ticket ID");
                    ChangeParameters(ticket);
                    break;
                case "2":
                    break;
                case "3":
                    break;
                case "4":
                    break;
                case "5":
                    break;
                case "6":
                    break;
                case "7":
                    break;
                case "8":
                    break;
                default:
                    Console.WriteLine("Input not recognised - please try again");
                    break;
            }
        }
       
    }
    }

