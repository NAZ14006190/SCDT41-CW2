﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CW2
{
    public static class Initialise
    {
        public static void Init()
        {
            Clerk TestClerk = new Clerk(1, "Gordon", "Freeman", 005491123, "gfreman@blackmesa.com");
            Labourer TestLabourer = new Labourer(2, "Alyx", "Vance", 564342354, "avance@blackmesa.com");

            //Ticket TestTicket = new Ticket("1", "Eli", "Vance", 43245431, "evance@mail.com");
        }
        
    }
}
