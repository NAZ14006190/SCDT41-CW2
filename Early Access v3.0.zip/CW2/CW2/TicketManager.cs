﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CW2
{
    public static class TicketManager
    {
        public static List<Ticket> AllTickets = new List<Ticket>();

        public static void AddTicket(Ticket ticket)
        {
            AllTickets.Add(ticket);
        }

        public static List<Ticket> SearchTickets (string search)
        {
            List<Ticket> results = new List<Ticket>();

            foreach (var ticket in AllTickets)
            {
                if (ticket.tenantsname == search)
                {
                    results.Add(ticket);
                }

            }
            return results;
        }

        public static void TicketUpdate (Ticket ticket)
        {
            bool ticketmenu = true;
            while (ticketmenu)
            {

                Console.WriteLine("Would like to make any changes?");
                var choice1 = Console.ReadLine();

                switch (choice1)
                {
                    case "1":
                        Console.WriteLine("Update Ticket ID");
                       
                        break;
                    case "2":
                        Console.WriteLine("Update Tenant's First Name");
                        ChangeParameters(ticket);
                        break;
                    case "3":
                        Console.WriteLine("Update Tenant's Second Name");
                        
                        break;
                    case "4":
                        Console.WriteLine("UpdateTenant's E-mail address");
                       
                        break;
                    case "5":
                        Console.WriteLine("Update Tenant's phone nubmer:");
                        
                        break;
                    case "6":
                        Console.WriteLine("Update Issues:");
                        
                        break;
                    case "7":
                        break;
                    case "8":
                        ticketmenu = false;
                        break;
                    default:
                        Console.WriteLine("Input not recognised - please try again");
                        break;
                }

            }
        }

        public static void ChangeParameters(Ticket ticket)
        {
            var updateticketid = Console.ReadLine();
            Console.WriteLine($"Updated ID - {updateticketid}");

            var updatetenantname = Console.ReadLine();
            Console.WriteLine($"Updated Tenant's First Name - {updatetenantname}");
            //Console.WriteLine(ticket);

        }














        public static Ticket GetTicket (string TicketID)
        {
            foreach (var ticket in AllTickets)
            {
                if (ticket.ticketid == TicketID)
                {
                    return ticket;
                }
            }
            return null;
        }

        public static void CreateTicket(List<Ticket> NewTickets) 
        {
            
        }
        public static void ChangeParameter(Ticket ticket)
        {

        }

    }
}
