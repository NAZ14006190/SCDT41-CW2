﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CW2
{
    public class Ticket
    {
     
        public string ticketid;
        public string tenantname;
        public string tenantsname;
        public int tenantnumber;
        public string tenantemail;
        //public PropertyType proprtytype;
        //public IssueType issuetype;
        public string issues;
        public string propertytype;
        public string status;

        public Ticket(string Ticketid, string Tenantname, string Tenantsname, int Tenantnumber, string Tenantemail, string Issues, string PropertyType, string Status)
        {
            this.ticketid = Ticketid;
            this.tenantname = Tenantname;
            this.tenantsname = Tenantsname;
            this.tenantnumber = Tenantnumber;
            this.tenantemail = Tenantemail;
            this.issues = Issues;
            this.propertytype = PropertyType;
            this.status = Status;
           // this.proprtytype = PropertyType.Residential; // by default
            //this.issuetype = IssueType.Cosmetic; // by default
        }

        public override string ToString()
        {
            return $"Customer Information:\nName: { tenantname} {tenantsname} \nE-mail Address: {tenantemail} \nNumber: {tenantnumber}\nIssues: {issues}\nProperty Type: {propertytype}\nTicket status: {status}";

        }

    }
}
