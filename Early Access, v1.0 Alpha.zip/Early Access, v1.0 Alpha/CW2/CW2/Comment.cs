﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CW2
{
    public class Comment
    {
        public Labourer labourer;
        public string comment;
        public DateTime timeStamp;

        public Comment(Labourer Labourer, string TicketComment)
        {
            this.timeStamp = DateTime.Now;
            this.labourer = Labourer;
            this.comment = TicketComment;
        }

    }
}
