﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CW2
{
    public enum PropertyType
    { 
        Commercial = 1,
        Residential = 2
    }
    
    public enum IssueType
    {
        Cosmetic = 1,
        Significant = 2
    }
}
