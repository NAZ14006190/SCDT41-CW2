﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CW2
{
    public abstract class User
    {
        private string fname;
        private string sname;
        private int phone_num;
        private string email;
        

        public User(string Fname, string Sname, int Phone_num, string Email)
        {
            this.fname = Fname;
            this.sname = Sname;
            this.phone_num = Phone_num;
            this.email = Email;
        }

        public User()
        {

        }
        public static List<Ticket> AllUsers = new List<Ticket>();

        public static void AddUser(Ticket user)
        {
            AllUsers.Add(user);
        }


    }
}
