﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CW2
{
    public class Clerk : User
    {
        public int clerkID { get; set; }
        public string fname { get; set; }
        public string sname { get; set; }
        public int phone_num { get; set; }
        public string email { get; set; }

        
        public Clerk(int ClerkID, string Fname, string Sname, int Phone_num, string Email): base(Fname, Sname, Phone_num, Email)
        {
            this.clerkID = ClerkID;
            this.fname = Fname;
            this.sname = Sname;
            this.phone_num = Phone_num;
            this.email = Email;
        }

    
    }
}
