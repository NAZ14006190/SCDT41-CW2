﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CW2
{
    public static class TicketManager
    {
        public static List<Ticket> AllTickets = new List<Ticket>();
        public static List<Clerk> AllClerks = new List<Clerk>();

        public static void AddTicket(Ticket ticket)
        {
            AllTickets.Add(ticket);
        }

        public static void AddClerks(Clerk clerk)
        {
            AllClerks.Add(clerk);
        }

        public static List<Ticket> SearchTickets (string search)
        {
            List<Ticket> results = new List<Ticket>();

            foreach (var ticket in AllTickets)
            {
                if (ticket.tenantsname == search)
                {
                    results.Add(ticket);
                }

            }
            return results;
        }
        public static Ticket GetTicket (int TicketID)
        {
            foreach (var ticket in AllTickets)
            {
                if (ticket.ticketid == TicketID)
                {
                    return ticket;
                }
            }
            return null;
        }
        public static void CreateTicket(List<Ticket> NewTickets) 
        {
            
        }
        public static void ChangeParameter(Ticket ticket)
        {

        }
    }
}
