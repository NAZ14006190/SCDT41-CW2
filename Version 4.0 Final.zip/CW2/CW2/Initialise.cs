﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CW2
{
    public static class Initialise
    {
        public static void Init()
        {
            Clerk TestClerk = new Clerk(1, "Gordon", "Freeman", 005491123, "gfreman@blackmesa.com");
            Labourer TestLabourer = new Labourer(2, "Alyx", "Vance", 564342354, "avance@blackmesa.com");

            TicketManager.AddClerks(TestClerk);

            Ticket TestTicket = new Ticket(1, "Eli", "Vance", 43245431, "21, New Street", "needs fitting bulb and teleport machine", "Significant", "Residential", "Closed", "Resourses used: 1 bulb, new wire. Time spent: 1 hour");
            Ticket TestTicket2 = new Ticket(2, "Isaac", "Kleiner", 01238543, "43, Hight Street", "pest infection", "Cosmetic", "Comercial", "Opened", "No comments yet");

            // Adding tickets ------------------------------------
            TicketManager.AddTicket(TestTicket);
            TicketManager.AddTicket(TestTicket2);

            //Ticket TestTicket = new Ticket("1", "Eli", "Vance", 43245431, "evance@mail.com");

           // Comment comment = new Comment(TestLabourer, "");
        }
        
    }
}
