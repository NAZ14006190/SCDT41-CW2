﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CW2
{
    public static class Authenticator
    {

        public static bool Authentificate(Clerk c, int cID)
        {
            if (c.clerkID == cID)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    }
}
