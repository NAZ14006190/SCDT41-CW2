﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace CW2
{
    public class CLI
    {

        public static void Login()
        {

            Labourer TestLabourer = new Labourer(2, "Alyx", "Vance", 564342354, "avance@blackmesa.com");
            Console.WriteLine("----------------------EM Login-----------------------");
            Console.WriteLine("Enter your unique login:");
            Console.WriteLine("-----------------------------------------------------\n");
            int id = Convert.ToInt32(Console.ReadLine());

          

            if (id == 1)
            {
                Console.WriteLine("Access type: Clerk");
                MainMenu();
                
            }
            if (id == TestLabourer.labourerID)
            {
                Console.WriteLine("Access type: Labourer");
                LabourMenu();
               
            }
            else
            {
                Console.WriteLine("Wrong login");
            }
        
          
        }
        public static void MainMenu()
        {
            
            bool menu = true;
           
            
            while (menu)
            {

                Console.WriteLine("\n---------------------------------------------");
                Console.WriteLine("Welcome to EM management menu\nPlease select one of the following options:");
                Console.WriteLine("\n1: Search for a ticket\n2: Edit existing ticket\n3: Create new ticket \n4: Exit\n");
                Console.WriteLine("---------------------------------------------");

                int menuchoice = Convert.ToInt32(Console.ReadLine());
                

                switch (menuchoice)
                {
                    case 1:
                        SearchTicket();
                        break;
                    case 2:
                        ChangeTicket();
                        break;
                    case 3:
                        CreateTicket();
                        break;
                    case 4:
                        menu = false;
                        Login();
                        break;
                    default:
                        Console.WriteLine("Input not recognised - please try again");
                        break;
                }
            }


        }
        public static void LabourMenu()
        {
            bool menu = true;


            while (menu)
            {

                Console.WriteLine("\n---------------------------------------------");
                Console.WriteLine("Welcome to EM management menu\nPlease select one of the following options:");
                Console.WriteLine("\n1: Search for a ticket\n2: Add comment to existing ticket\n3: Exit");

                int menuchoice = Convert.ToInt32(Console.ReadLine());


                switch (menuchoice)
                {
                    case 1:
                        SearchTicket();
                        break;
                    case 2:
                        AddComment();
                        break;
                    case 3:
                        menu = false;
                        Login();
                        break;
                    default:
                        Console.WriteLine("Input not recognised - please try again");
                        break;
                }
            }


        }
        /*
        public static object GetPropValue(object src, string propName)
        {
            return src.GetType().GetProperty(propName).GetValue(src, null);
        }*/
        public static void AddComment() // Add comment method
        {

            Labourer TestLabourer2 = new  Labourer(42,"Barney","Calhoun", 543124, "");
            //Console.WriteLine(TestLabourer2);
           // Labourer TestLabourer = new Labourer(351, "Alyx", "Vance", 564342354, "avance@blackmesa.com");

            Console.WriteLine("Please, type ID of a ticket you would like to add comment: ");
            int ticketid = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Update comment: ");
            string comment = Console.ReadLine();

            Console.WriteLine("How many hours spent: ");
            double hours = Convert.ToDouble(Console.ReadLine());
            
            

            Console.WriteLine($"\nWork has been done: {comment}\nHours spent: {hours}\n{TestLabourer2}\nComment added at: {DateTime.Now}");


           // Comment comment1 =  new Comment(TestLabourer2, comment);
           // Console.WriteLine(comment1);
        }
        public static void SearchTicket() // Search for a ticket method
        {
            Console.WriteLine("Input search tenant's surname ");
            string search = Console.ReadLine();
            var results = TicketManager.SearchTickets(search);


            if (results.Count != 0)
            {
                foreach (Ticket item in results)
                {
                    Console.WriteLine("\n********************************\n");
                    Console.WriteLine($"1. Ticket ID: {item.ticketid}");
                    Console.WriteLine($"2. Tenant's First Name: {item.tenantname}");
                    Console.WriteLine($"3. Tenant's Second Name: {item.tenantsname}");
                    Console.WriteLine($"4. Tenant's E-mail address: {item.tenantaddress}");
                    Console.WriteLine($"5. Tenant's phone nubmer: {item.tenantnumber}");
                    Console.WriteLine($"6. Issues: {item.issues}");
                    Console.WriteLine($"6. Issue type: {item.issueType}");
                    Console.WriteLine($"7. Property type: {item.propertytype}");
                    Console.WriteLine("\n********************************\n");

                }
            }
            else
            {
                Console.WriteLine("Sorry, no tenants wtih this surname are registered");
            }


        }
        public static void ChangeTicket() // Chane Ticket method
        {
            bool ticketmenu = true;
            //Ticket TestTicket4 = new Ticket(0, "", "", 0, "", "", "", "", "");
            //TestTicket4.comments.Add(new Comment(labourer,
            while (ticketmenu)
            {
               
                Console.WriteLine("Please, type a Ticket ID, of a ticekt you would like to change?");

               string search = Console.ReadLine();
               var results = TicketManager.SearchTickets(search);

                Console.WriteLine("\nWhat woul you like to change?\n1. Ticket ID\n2. Tenant's First Name\n3. Tenant's Last Name\n4. Tenant's Address\n5. Tenant's phone number\n6. Update issues\n7. Ticket status\n8. Exit");
                string choice1 = Console.ReadLine();

                switch (choice1)
                {
                    case "1":
                        Console.WriteLine("Update Ticket ID");
                        int newid = Convert.ToInt32(Console.ReadLine());
                        Console.WriteLine($"ID has been updated to - {newid}");
                        break;
                    case "2":
                        Console.WriteLine("Update Tenant's First Name");
                        string updatedtenantfname = Console.ReadLine();
                        Console.WriteLine($"Tenant's First Name has been updated to {updatedtenantfname}");
                        break;
                    case "3":
                        Console.WriteLine("Update Tenant's Second Name");
                        string updatedtenantsname = Console.ReadLine();
                        Console.WriteLine($"Tenant's Second Name has been updated to {updatedtenantsname}");
                        break;
                    case "4":
                        Console.WriteLine("Update Tenant's address");
                        string updatedtenantaddress = Console.ReadLine();
                        Console.WriteLine($"Tenant's Second Name has been updated to {updatedtenantaddress}");
                        break;
                    case "5":
                        Console.WriteLine("Update Tenant's phone nubmer:");
                        int updatedtenantnumber = Convert.ToInt32(Console.ReadLine());
                        Console.WriteLine($"Tenant's Second Name has been updated to {updatedtenantnumber}");
                        break;
                    case "6":
                        Console.WriteLine("Update Issues:");
                        string updatedissues = Console.ReadLine();
                        Console.WriteLine($"Tenant's Second Name has been updated to {updatedissues}");
                        break;
                    case "7":
                        Console.WriteLine("Update Status:");
                        string updatedstatus = Console.ReadLine();
                        Console.WriteLine($"Tenant's Second Name has been updated to {updatedstatus}");
                        break;
                    case "8":
                        ticketmenu = false;
                        break;
                    default:
                        Console.WriteLine("Input not recognised - please try again");
                        break;
                }

            }

        }
      
        /*
        public static void ChangeParameters(Ticket ticket)
        {

            string updateticketid = Console.ReadLine();
            Console.WriteLine($"Updated ID - {updateticketid}");
            
            string updatetenantname = Console.ReadLine();
            Console.WriteLine($"Updated Tenant's First Name - {updatetenantname}");

            string updatetenantsname = Console.ReadLine();
            Console.WriteLine($"Updated Tenant's Last Name - {updatetenantsname}");

            string updatetenantaddress = Console.ReadLine();
            Console.WriteLine($"Updated Tenant's address - {updatetenantaddress}");

            int updatetenantnumber = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine($"Updated Tenant's phone number - {updatetenantnumber}");

            string updatetenantissues = Console.ReadLine();
            Console.WriteLine($"Updated Ticket issues - {updatetenantissues}");

            int updatetenantstatus = Convert.ToInt32(Console.ReadLine());
            if (updatetenantstatus == 1)
            {
                Console.WriteLine("Updated Ticktet status - Opened");
            }
            if (updatetenantstatus == 2)
            {
                Console.WriteLine("Updated Ticktet status- Closed");
            }
            Console.WriteLine($"Updated Tenant's Last Name - {updatetenantissues}");

        }*/
        public static Ticket CreateTicket()
        {
            // Create object from user input
            Console.WriteLine("\n*************\nCreate Customer\n**************");
            Console.WriteLine("Enter Ticket ID");
            int ticketid = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter Customer First Name");
            string tenantname = Console.ReadLine();

            Console.WriteLine("Enter Customer Second Name");
            string tenantsname = Console.ReadLine();

            Console.WriteLine("Enter Customer Address");
            string tenantaddress = Console.ReadLine();

            Console.WriteLine("Enter Customer Phone number");
            int tenantnumber = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter issues");
            string issues = Console.ReadLine();

            Console.WriteLine("Enter issue type (1 Cosmetic, 2 - Significant)");
            string issueType = Console.ReadLine();
            if (issueType  == "1")
            {
                issueType = "Cosmetic";
            }
            if (issueType == "2")
            {
                issueType = "Significant";
            }
            
            Console.WriteLine("Enter property type (1 - Resindetial, 2 - Commercieal)");
            string propertytype = Console.ReadLine();
            if (propertytype == "1")
            {
                propertytype = "Residential";
            }
            if (propertytype == "2")
            {
                propertytype = "Comercial";
            }
            else
            {
                Console.WriteLine("Should be a number 1 or 2");
            }
            Console.WriteLine("Enter status type (1 - Opened , 2 - Closed)");
            string status = Console.ReadLine();
            if (status == "1")
            {
                status = "Opened";
            }
            if (status == "2")
            {
                status = "Closed";
            }
            

             Ticket TestTicket3 = new   Ticket (ticketid, tenantname, tenantsname, tenantnumber, tenantaddress, issues, issueType, propertytype, status,"");
             Console.WriteLine(TestTicket3);

            // JSON example
            List<Ticket> tickets = new List<Ticket>();
            tickets.Add(TestTicket3);

            var json = JsonConvert.SerializeObject(tickets);


            using (StreamWriter file = File.CreateText(@"C:\Users\Michael\Desktop\Uni\SCDT41 Programming and Software Fundamentals (James Shaun)\Assignment 2\CW2\test.json"))
            {
                JsonSerializer serializer = new JsonSerializer();
                serializer.Serialize(file, TestTicket3);

            }
            //----------------------
            return TestTicket3;
            


            

        }
    }
    }

