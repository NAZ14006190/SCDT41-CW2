﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CW2
{
    public class Ticket
    {
     
        public int ticketid;
        public string tenantname;
        public string tenantsname;
        public int tenantnumber;
        public string tenantaddress;
        public string issues;
        public string issueType;
        public string propertytype;
        public string status;
        public string comment;
        public DateTime timeStamp;

        public Ticket(int Ticketid, string Tenantname, string Tenantsname, int Tenantnumber, string Tenantaddress, string Issues, string IssueType, string PropertyType, string Status, string Comment)
        {
            this.ticketid = Ticketid;
            this.tenantname = Tenantname;
            this.tenantsname = Tenantsname;
            this.tenantnumber = Tenantnumber;
            this.tenantaddress = Tenantaddress;
            this.issues = Issues;
            this.propertytype = PropertyType;
            this.status = Status;
            this.issueType = IssueType;
            this.timeStamp = DateTime.Now;
            this.comment = Comment;
            
           // this.proprtytype = PropertyType.Residential; // by default
            //this.issuetype = IssueType.Cosmetic; // by default
        }


        public override string ToString()
        {
            return $"Ticket Information:\nTicket ID: {ticketid}\nName: {tenantname} {tenantsname} \nAddress: {tenantaddress} \nNumber: {tenantnumber}\nIssues: {issues}\nIssue type: {issueType}\nProperty Type: {propertytype}\nStatus: {status}";

        }

    }
}
