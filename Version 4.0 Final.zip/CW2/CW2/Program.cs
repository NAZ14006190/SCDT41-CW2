﻿using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;

namespace CW2
{
    class Program
    {
        static void Main(string[] args)
        {


            // Version 3.0
            Initialise.Init();
           
            while (true)
            {
                CLI.Login();
            }
            

        }
    }
}

